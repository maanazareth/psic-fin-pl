-- Execute este SQL no Supabase → SQL Editor

-- Tabela de questões
create table if not exists questions (
  id serial primary key,
  numero integer not null,
  parte integer not null, -- 1 ou 2
  topic text not null,
  text text not null,
  options jsonb not null, -- array de strings
  correct_index integer not null,
  explanation text not null,
  created_at timestamptz default now()
);

-- Tabela de respostas dos usuários
create table if not exists user_answers (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references auth.users(id) on delete cascade not null,
  question_id integer references questions(id) on delete cascade not null,
  selected_index integer not null,
  is_correct boolean not null,
  answered_at timestamptz default now(),
  unique(user_id, question_id)
);

-- Habilitar Row Level Security
alter table user_answers enable row level security;
alter table questions enable row level security;

-- Policies: qualquer usuário autenticado pode ler questões
create policy "Questões públicas para autenticados"
  on questions for select
  to authenticated
  using (true);

-- Policies: usuário só vê e altera suas próprias respostas
create policy "Usuário vê suas respostas"
  on user_answers for select
  to authenticated
  using (auth.uid() = user_id);

create policy "Usuário insere suas respostas"
  on user_answers for insert
  to authenticated
  with check (auth.uid() = user_id);

create policy "Usuário atualiza suas respostas"
  on user_answers for update
  to authenticated
  using (auth.uid() = user_id);

-- View para dashboard de resultados por tema
create or replace view user_results_by_topic as
select
  ua.user_id,
  q.topic,
  q.parte,
  count(*) as total,
  sum(case when ua.is_correct then 1 else 0 end) as acertos,
  round(sum(case when ua.is_correct then 1 else 0 end)::numeric / count(*) * 100, 1) as aproveitamento
from user_answers ua
join questions q on q.id = ua.question_id
group by ua.user_id, q.topic, q.parte;

-- Policy para a view
create policy "Usuário vê seu resultado por tema"
  on user_answers for select
  to authenticated
  using (auth.uid() = user_id);
