# CFP Módulo 8 — Plataforma de Questões

Plataforma web completa com login, memória de respostas e dashboard de resultados por tema para o Módulo 8 da certificação CFP® (Psicologia no Planejamento Financeiro).

---

## Stack

- **Frontend**: React 18 + Vite
- **Autenticação + Banco de dados**: Supabase (gratuito)
- **Hospedagem**: Vercel (gratuito)
- **Fontes**: Syne + DM Sans (Google Fonts)

---

## Passo a passo para colocar no ar

### 1. Criar conta no Supabase (gratuito)

1. Acesse [https://app.supabase.com](https://app.supabase.com)
2. Clique em **Start your project** e crie uma conta (pode usar Google)
3. Clique em **New project**
4. Escolha um nome (ex: `cfp-modulo8`), defina uma senha para o banco e escolha a região **South America (São Paulo)**
5. Aguarde ~2 minutos o projeto ser criado

### 2. Configurar o banco de dados

1. No painel do Supabase, clique em **SQL Editor** no menu lateral
2. Clique em **New query**
3. Cole todo o conteúdo do arquivo `supabase_setup.sql` (que está na pasta do projeto)
4. Clique em **Run** (ícone de play)
5. Deve aparecer "Success" para cada comando

### 3. Obter as credenciais do Supabase

1. No painel do Supabase, vá em **Settings** → **API**
2. Copie:
   - **Project URL** (ex: `https://xyzxyz.supabase.co`)
   - **anon public** key (chave longa que começa com `eyJ...`)

### 4. Configurar as variáveis de ambiente localmente

1. Na pasta do projeto, copie o arquivo de exemplo:
   ```
   cp .env.example .env
   ```
2. Abra o arquivo `.env` e substitua os valores:
   ```
   VITE_SUPABASE_URL=https://SEU_PROJETO.supabase.co
   VITE_SUPABASE_ANON_KEY=SUA_CHAVE_ANON_PUBLICA
   ```

### 5. Instalar dependências e testar localmente

Você precisa ter o [Node.js](https://nodejs.org) instalado (versão 18+).

```bash
# Dentro da pasta do projeto
npm install
npm run dev
```

Acesse [http://localhost:5173](http://localhost:5173) — a plataforma deve abrir.

### 6. Publicar no Vercel (gratuito)

**Opção A — Via GitHub (recomendado):**

1. Crie uma conta em [https://github.com](https://github.com)
2. Crie um novo repositório e faça upload dos arquivos do projeto
3. Acesse [https://vercel.com](https://vercel.com) e crie uma conta (pode usar Google ou GitHub)
4. Clique em **Add New → Project**
5. Conecte o repositório GitHub que você criou
6. Na tela de configuração, clique em **Environment Variables** e adicione:
   - `VITE_SUPABASE_URL` → sua URL do Supabase
   - `VITE_SUPABASE_ANON_KEY` → sua chave anon
7. Clique em **Deploy**
8. Em ~1 minuto, o site estará no ar com uma URL do tipo `cfp-modulo8.vercel.app`

**Opção B — Via Vercel CLI:**

```bash
npm install -g vercel
vercel login
vercel
# Siga as instruções e configure as variáveis de ambiente quando solicitado
```

### 7. Domínio personalizado (opcional)

1. Registre um domínio em [https://registro.br](https://registro.br) (~R$ 40/ano para .com.br)
2. No painel do Vercel, vá em **Settings → Domains**
3. Adicione seu domínio e siga as instruções de configuração DNS

---

## Funcionalidades da plataforma

- **Login e cadastro** com e-mail e senha
- **60 questões** com 4 alternativas cada (30 por parte)
- **Feedback imediato** com explicação detalhada após cada resposta
- **Memória persistente**: respostas salvas — ao voltar, o progresso está mantido
- **Filtro por parte** (Parte 1 / Parte 2) e **por tema**
- **Dashboard de resultados** com:
  - Total de respondidas, acertos, erros e aproveitamento geral
  - Barra de progresso geral
  - Aproveitamento por tema com indicação visual (verde ≥70%, amarelo ≥50%, vermelho <50%)
  - Indicação se está acima ou abaixo da meta CFP (70%)

---

## Estrutura de arquivos

```
cfp-quiz/
├── index.html
├── package.json
├── vite.config.js
├── .env.example           ← copie para .env e preencha
├── supabase_setup.sql     ← execute no Supabase SQL Editor
└── src/
    ├── main.jsx
    ├── App.jsx
    ├── index.css
    ├── lib/
    │   ├── supabase.js    ← cliente Supabase
    │   └── questions.js   ← banco das 60 questões
    ├── hooks/
    │   ├── useAuth.js     ← autenticação
    │   └── useAnswers.js  ← salvar/carregar respostas
    ├── components/
    │   ├── QuestionCard.jsx
    │   └── QuestionCard.module.css
    └── pages/
        ├── Auth.jsx / Auth.module.css
        ├── Quiz.jsx / Quiz.module.css
        └── Dashboard.jsx / Dashboard.module.css
```

---

## Custo estimado

| Serviço | Plano | Custo |
|---|---|---|
| Supabase | Free | R$ 0/mês |
| Vercel | Hobby | R$ 0/mês |
| Domínio .com.br | — | ~R$ 40/ano |
| **Total** | | **~R$ 3,30/mês** |

---

## Suporte

Em caso de dúvidas sobre o deploy, consulte:
- [Documentação do Supabase](https://supabase.com/docs)
- [Documentação do Vercel](https://vercel.com/docs)
