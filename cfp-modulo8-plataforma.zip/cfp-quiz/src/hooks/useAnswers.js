import { useState, useEffect, useCallback } from 'react'
import { supabase } from '../lib/supabase'

export function useAnswers(userId) {
  const [answers, setAnswers] = useState({}) // { questionId: { selected, isCorrect } }
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!userId) { setLoading(false); return }

    supabase
      .from('user_answers')
      .select('question_id, selected_index, is_correct')
      .eq('user_id', userId)
      .then(({ data }) => {
        const map = {}
        data?.forEach(r => { map[r.question_id] = { selected: r.selected_index, isCorrect: r.is_correct } })
        setAnswers(map)
        setLoading(false)
      })
  }, [userId])

  const submitAnswer = useCallback(async (questionId, selectedIndex, isCorrect) => {
    setAnswers(prev => ({ ...prev, [questionId]: { selected: selectedIndex, isCorrect } }))

    await supabase.from('user_answers').upsert({
      user_id: userId,
      question_id: questionId,
      selected_index: selectedIndex,
      is_correct: isCorrect,
      answered_at: new Date().toISOString()
    }, { onConflict: 'user_id,question_id' })
  }, [userId])

  return { answers, loading, submitAnswer }
}
