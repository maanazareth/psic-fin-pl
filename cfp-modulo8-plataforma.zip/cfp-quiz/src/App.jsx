import { useState } from 'react'
import { useAuth } from './hooks/useAuth'
import Auth from './pages/Auth'
import Quiz from './pages/Quiz'
import Dashboard from './pages/Dashboard'

export default function App() {
  const { user, loading, signOut } = useAuth()
  const [page, setPage] = useState('quiz') // 'quiz' | 'dashboard'

  if (loading) {
    return (
      <div style={{
        minHeight: '100vh', display: 'flex', alignItems: 'center',
        justifyContent: 'center', background: '#0f1117',
        color: '#475569', fontFamily: 'DM Sans, sans-serif', fontSize: 14
      }}>
        Carregando...
      </div>
    )
  }

  if (!user) return <Auth />

  if (page === 'dashboard') {
    return (
      <Dashboard
        user={user}
        onGoToQuiz={() => setPage('quiz')}
        onSignOut={signOut}
      />
    )
  }

  return (
    <Quiz
      user={user}
      onGoToDashboard={() => setPage('dashboard')}
      onSignOut={signOut}
    />
  )
}
