import styles from './QuestionCard.module.css'

const TOPIC_COLORS = {
  'Fundamentos': '#3b82f6',
  'Teoria da Perspectiva': '#8b5cf6',
  'Vieses cognitivos': '#10b981',
  'Emoções e decisão': '#f59e0b',
  'Scripts financeiros': '#06b6d4',
  'Relacionamento': '#ec4899',
  'Nudges': '#f97316',
  'Bem-estar financeiro': '#84cc16',
  'Ética e vieses do planejador': '#ef4444',
  'Relacionamento avançado': '#ec4899',
}

export default function QuestionCard({ question, savedAnswer, onAnswer }) {
  const color = TOPIC_COLORS[question.topic] || '#64748b'
  const answered = savedAnswer !== undefined

  return (
    <div className={styles.card}>
      <div className={styles.meta}>
        <span className={styles.badge} style={{ background: color + '22', color }}>
          {question.topic}
        </span>
        <span className={styles.num}>Questão {question.numero}</span>
      </div>

      <p className={styles.text}>{question.text}</p>

      <div className={styles.options}>
        {question.options.map((opt, i) => {
          let cls = styles.option
          if (answered) {
            if (i === question.correct) cls = `${styles.option} ${styles.correct}`
            else if (i === savedAnswer.selected && i !== question.correct) cls = `${styles.option} ${styles.wrong}`
            else cls = `${styles.option} ${styles.dim}`
          }
          return (
            <button
              key={i}
              className={cls}
              onClick={() => !answered && onAnswer(question.id, i, i === question.correct)}
              disabled={answered}
            >
              <span className={styles.letter}>{String.fromCharCode(65 + i)}</span>
              {opt}
            </button>
          )
        })}
      </div>

      {answered && (
        <div className={`${styles.feedback} ${savedAnswer.isCorrect ? styles.feedbackOk : styles.feedbackNo}`}>
          <strong>{savedAnswer.isCorrect ? 'Correto!' : 'Incorreto.'}</strong>{' '}
          {question.explanation}
        </div>
      )}
    </div>
  )
}
