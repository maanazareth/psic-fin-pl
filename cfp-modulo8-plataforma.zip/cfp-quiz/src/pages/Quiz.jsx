import { useState, useMemo } from 'react'
import { questions } from '../lib/questions'
import { useAnswers } from '../hooks/useAnswers'
import QuestionCard from '../components/QuestionCard'
import styles from './Quiz.module.css'

const TOPICS = ['Todos', ...Array.from(new Set(questions.map(q => q.topic)))]

export default function Quiz({ user, onGoToDashboard, onSignOut }) {
  const { answers, loading, submitAnswer } = useAnswers(user.id)
  const [parte, setParte] = useState(1)
  const [topicFilter, setTopicFilter] = useState('Todos')

  const filtered = useMemo(() =>
    questions.filter(q =>
      q.parte === parte &&
      (topicFilter === 'Todos' || q.topic === topicFilter)
    ),
    [parte, topicFilter]
  )

  const total = questions.length
  const done = Object.keys(answers).length
  const correct = Object.values(answers).filter(a => a.isCorrect).length
  const pct = done > 0 ? Math.round(correct / done * 100) : 0

  if (loading) return <div className={styles.loading}>Carregando...</div>

  return (
    <div className={styles.page}>
      <header className={styles.header}>
        <div className={styles.headerLeft}>
          <div className={styles.logo}>CFP</div>
          <div>
            <p className={styles.headerTitle}>Módulo 8</p>
            <p className={styles.headerSub}>Psicologia no Planejamento Financeiro</p>
          </div>
        </div>
        <div className={styles.headerRight}>
          <button className={styles.btnDash} onClick={onGoToDashboard}>Dashboard</button>
          <button className={styles.btnOut} onClick={onSignOut}>Sair</button>
        </div>
      </header>

      <div className={styles.statsBar}>
        <div className={styles.stat}>
          <span className={styles.statVal}>{done}/{total}</span>
          <span className={styles.statLabel}>respondidas</span>
        </div>
        <div className={styles.stat}>
          <span className={styles.statVal} style={{ color: '#10b981' }}>{correct}</span>
          <span className={styles.statLabel}>acertos</span>
        </div>
        <div className={styles.stat}>
          <span className={styles.statVal} style={{ color: '#ef4444' }}>{done - correct}</span>
          <span className={styles.statLabel}>erros</span>
        </div>
        <div className={styles.stat}>
          <span className={styles.statVal} style={{ color: pct >= 70 ? '#10b981' : pct >= 50 ? '#f59e0b' : '#ef4444' }}>
            {pct}%
          </span>
          <span className={styles.statLabel}>aproveitamento</span>
        </div>
        <div className={styles.progressWrap}>
          <div className={styles.progressBar} style={{ width: `${Math.round(done / total * 100)}%` }} />
        </div>
      </div>

      <div className={styles.controls}>
        <div className={styles.partes}>
          {[1, 2].map(p => (
            <button
              key={p}
              className={`${styles.parteBtn} ${parte === p ? styles.parteActive : ''}`}
              onClick={() => { setParte(p); setTopicFilter('Todos') }}
            >
              Parte {p} — {p === 1 ? '30 questões' : '30 questões'}
            </button>
          ))}
        </div>

        <select
          className={styles.topicSelect}
          value={topicFilter}
          onChange={e => setTopicFilter(e.target.value)}
        >
          {TOPICS.filter(t => t === 'Todos' || questions.some(q => q.parte === parte && q.topic === t)).map(t => (
            <option key={t} value={t}>{t}</option>
          ))}
        </select>
      </div>

      <div className={styles.questions}>
        {filtered.map(q => (
          <QuestionCard
            key={q.id}
            question={q}
            savedAnswer={answers[q.id]}
            onAnswer={submitAnswer}
          />
        ))}
      </div>
    </div>
  )
}
