import { useMemo } from 'react'
import { questions } from '../lib/questions'
import { useAnswers } from '../hooks/useAnswers'
import styles from './Dashboard.module.css'

const TOPIC_COLORS = {
  'Fundamentos': '#3b82f6',
  'Teoria da Perspectiva': '#8b5cf6',
  'Vieses cognitivos': '#10b981',
  'Emoções e decisão': '#f59e0b',
  'Scripts financeiros': '#06b6d4',
  'Relacionamento': '#ec4899',
  'Nudges': '#f97316',
  'Bem-estar financeiro': '#84cc16',
  'Ética e vieses do planejador': '#ef4444',
  'Relacionamento avançado': '#ec4899',
}

export default function Dashboard({ user, onGoToQuiz, onSignOut }) {
  const { answers, loading } = useAnswers(user.id)

  const stats = useMemo(() => {
    const byTopic = {}

    questions.forEach(q => {
      if (!byTopic[q.topic]) byTopic[q.topic] = { total: 0, answered: 0, correct: 0 }
      byTopic[q.topic].total++
      const a = answers[q.id]
      if (a !== undefined) {
        byTopic[q.topic].answered++
        if (a.isCorrect) byTopic[q.topic].correct++
      }
    })

    return Object.entries(byTopic).map(([topic, data]) => ({
      topic,
      ...data,
      pct: data.answered > 0 ? Math.round(data.correct / data.answered * 100) : null
    })).sort((a, b) => (a.pct ?? -1) - (b.pct ?? -1))
  }, [answers])

  const total = questions.length
  const done = Object.keys(answers).length
  const correct = Object.values(answers).filter(a => a.isCorrect).length
  const overall = done > 0 ? Math.round(correct / done * 100) : 0

  if (loading) return <div className={styles.loading}>Carregando...</div>

  return (
    <div className={styles.page}>
      <header className={styles.header}>
        <div className={styles.headerLeft}>
          <div className={styles.logo}>CFP</div>
          <div>
            <p className={styles.headerTitle}>Dashboard</p>
            <p className={styles.headerSub}>{user.email}</p>
          </div>
        </div>
        <div className={styles.headerRight}>
          <button className={styles.btnQuiz} onClick={onGoToQuiz}>Ir para questões</button>
          <button className={styles.btnOut} onClick={onSignOut}>Sair</button>
        </div>
      </header>

      <div className={styles.content}>
        <div className={styles.summaryGrid}>
          <div className={styles.summaryCard}>
            <span className={styles.bigNum}>{done}</span>
            <span className={styles.bigLabel}>de {total} respondidas</span>
            <div className={styles.miniBar}>
              <div className={styles.miniBarFill} style={{ width: `${Math.round(done/total*100)}%`, background: '#2563eb' }} />
            </div>
          </div>
          <div className={styles.summaryCard}>
            <span className={styles.bigNum} style={{ color: '#10b981' }}>{correct}</span>
            <span className={styles.bigLabel}>acertos</span>
          </div>
          <div className={styles.summaryCard}>
            <span className={styles.bigNum} style={{ color: '#ef4444' }}>{done - correct}</span>
            <span className={styles.bigLabel}>erros</span>
          </div>
          <div className={styles.summaryCard}>
            <span
              className={styles.bigNum}
              style={{ color: overall >= 70 ? '#10b981' : overall >= 50 ? '#f59e0b' : '#ef4444' }}
            >
              {overall}%
            </span>
            <span className={styles.bigLabel}>aproveitamento geral</span>
            {done > 0 && (
              <span className={styles.verdict}>
                {overall >= 70 ? 'Acima da meta CFP (70%)' : overall >= 50 ? 'Abaixo da meta — continue!' : 'Reforçar estudo'}
              </span>
            )}
          </div>
        </div>

        <h2 className={styles.sectionTitle}>Resultado por tema</h2>

        <div className={styles.topicList}>
          {stats.map(s => {
            const color = TOPIC_COLORS[s.topic] || '#64748b'
            const barPct = s.pct ?? 0
            return (
              <div key={s.topic} className={styles.topicRow}>
                <div className={styles.topicMeta}>
                  <span className={styles.topicDot} style={{ background: color }} />
                  <span className={styles.topicName}>{s.topic}</span>
                  <span className={styles.topicCount}>{s.answered}/{s.total}</span>
                </div>
                <div className={styles.topicBarWrap}>
                  <div
                    className={styles.topicBar}
                    style={{
                      width: `${barPct}%`,
                      background: s.pct === null ? '#1e293b' : s.pct >= 70 ? '#10b981' : s.pct >= 50 ? '#f59e0b' : '#ef4444'
                    }}
                  />
                </div>
                <span
                  className={styles.topicPct}
                  style={{ color: s.pct === null ? '#475569' : s.pct >= 70 ? '#10b981' : s.pct >= 50 ? '#f59e0b' : '#ef4444' }}
                >
                  {s.pct !== null ? `${s.pct}%` : '—'}
                </span>
              </div>
            )
          })}
        </div>

        {done === 0 && (
          <div className={styles.empty}>
            Nenhuma questão respondida ainda.{' '}
            <button className={styles.emptyBtn} onClick={onGoToQuiz}>Começar agora</button>
          </div>
        )}
      </div>
    </div>
  )
}
